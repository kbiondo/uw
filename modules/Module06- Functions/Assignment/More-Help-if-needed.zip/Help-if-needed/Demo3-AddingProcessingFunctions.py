# Data -------------------------------------------------------------------- #
strChoice = ""  # Capture the user option selection
lstTable = []  # Holds a table of data
strFileName = "HomeInventory.txt"

# Processing  --------------------------------------------------------------- #
class Processor:
    """ Processes the data in a list of dictionaries to and from a text file """

    @staticmethod
    def read_file_to_list_of_dictionaries(file_name, list_of_dictionary_rows):
        list_of_dictionary_rows.clear()  # clear any old data before loading
        file = open(file_name, "r")  # Causes ERROR if file does not exist!
        for line in file:
            item, value = line.split(",")
            row = {"Item": item.strip(), "Value": value.strip()}
            list_of_dictionary_rows.append(row)
        file.close()
        return list_of_dictionary_rows, 'success'

    @staticmethod
    def add_data_to_list_of_dictionaries(list_of_dictionary_rows, item, value):
        row = {"Item": str(item).strip(), "Value": str(value).strip()}
        list_of_dictionary_rows.append(row)
        return list_of_dictionary_rows, 'success'

    @staticmethod
    def remove_data_from_list_of_dictionaries(list_of_dictionary_rows, item_to_remove):
        for row in list_of_dictionary_rows:
            if row["Item"].lower() == item_to_remove.lower():
                lstTable.remove(row)
                # print("row removed")
        return list_of_dictionary_rows, 'success'

    @staticmethod
    def write_file_from_list_of_dictionaries(file_name, list_of_dictionary_rows):
        file = open(file_name, "w")
        for row in list_of_dictionary_rows:
            file.write(row["Item"] + "," + row["Value"] + "\n")
        file.close()
        return list_of_dictionary_rows, 'success'

# Presentation (Input/Output)  -------------------------------------------- #
# TBD

""" ----------------- Main Body of the Script ----------------"""
# Test read file
lstTable, status  = Processor.read_file_to_list_of_dictionaries(strFileName, lstTable)
print(lstTable)
print(status)

# Test add data
lstTable, status = Processor.add_data_to_list_of_dictionaries(lstTable, "Lamp", 200)
print(lstTable)
print(status)

# Test remove data
# lstTable, status  = Processor.remove_data_from_list_of_dictionaries(lstTable, "Lamp")
# print(lstTable)
# print(status)

# Test write data
lstTable, status  = Processor.write_file_from_list_of_dictionaries(strFileName, lstTable)
print(lstTable)
print(status)