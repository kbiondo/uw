# Data -------------------------------------------------------------------- #
strChoice = ""  # Capture the user option selection
lstTable = [ {"Item": "Lamp", "Value": "20"},
                   {"Item": "Desk", "Value": "100"} ] # Holds a table of data
strItem = ""
strValue = ""

# Processing  --------------------------------------------------------------- #
# TBD

# Presentation (Input/Output)  -------------------------------------------- #
class IO:
    @staticmethod
    def print_menu():
        print('''
        Menu of Options
        1) Load Data from File
        2) Add a new item
        3) Remove an existing item
        4) Save Data to File And Exit Program
        ''')

    @staticmethod
    def input_menu_choice():
        choice = str(input("Which option would you like to perform? [1 to 4] - ")).strip()
        print()  # Add an extra line for looks
        return choice

    @staticmethod
    def print_current_list_items(list_of_rows):
        print("******* The Current Items Are: *******")
        for row in list_of_rows:
            print(row["Item"] + " (" + row["Value"] + ")")
        print("*******************************************")
        print()  # Add an extra line for looks

    @staticmethod
    def input_item_and_value():
        item = str(input("What is the item? - ")).strip()
        value = str(input("What is the value? - ")).strip()
        print()  # Add an extra line for looks
        return item, value

    @staticmethod
    def input_item_to_remove():
        item = str(input("Remove which item? - ")).strip()
        print()  # Add an extra line for looks
        return item

""" ----------------- Main Body of the Script ----------------"""



# test menu
IO.print_menu()

# test showing table data
IO.print_current_list_items(lstTable)

# test user choice
strChoice = IO.input_menu_choice()
print(strChoice)

# test new data input
strItem, strValue = IO.input_item_and_value()
print(strChoice)

# test remove data input
strItem = IO.input_item_to_remove()
print(strChoice)
