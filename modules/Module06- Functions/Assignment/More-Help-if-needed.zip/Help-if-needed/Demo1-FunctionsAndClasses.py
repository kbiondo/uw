
""" Function and Class Definitions """

def function01():
    print("function01 code goes here")


def function02():
    print("function02 code goes here")
    x = input("asdf")
    print(x)



class class01:

    @staticmethod  # @classfunction
    def function03():
        print("function03 code goes here in Class 01")


""" Main Body of the Script"""
function01()
function02()

class01.function03()

