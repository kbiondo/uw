# Data -------------------------------------------------------------------- #
strChoice = ""  # Capture the user option selection
strItem = ""
strValue = ""

lstTable = []  # Holds a table of data
strFileName = "HomeInventory.txt"

# Processing  --------------------------------------------------------------- #
class Processor:
    """ Processes the data in a list of dictionaries to and from a text file """

    @staticmethod
    def read_file_to_list_of_dictionaries(file_name, list_of_dictionary_rows):
        list_of_dictionary_rows.clear()  # clear any old data before loading
        file = open(file_name, "r")  # Causes ERROR if file does not exist!
        for line in file:
            item, value = line.split(",")
            row = {"Item": item.strip(), "Value": value.strip()}
            list_of_dictionary_rows.append(row)
        file.close()
        return list_of_dictionary_rows, 'success'

    @staticmethod
    def remove_data_from_list_of_dictionaries(list_of_dictionary_rows, item_to_remove):
        for row in list_of_dictionary_rows:
            if row["Item"].lower() == item_to_remove.lower():
                lstTable.remove(row)
                # print("row removed")
        return list_of_dictionary_rows, 'success'

    @staticmethod
    def add_data_to_list_of_dictionaries(list_of_dictionary_rows, item, value):
        row = {"Item": str(item).strip(), "Value": str(value).strip()}
        list_of_dictionary_rows.append(row)
        return list_of_dictionary_rows, 'success'

    @staticmethod
    def write_file_from_list_of_dictionaries(file_name, list_of_dictionary_rows):
        file = open(file_name, "w")
        for row in list_of_dictionary_rows:
            file.write(row["Item"] + "," + row["Value"] + "\n")
        file.close()
        return list_of_dictionary_rows, 'success'

# Presentation (Input/Output)  -------------------------------------------- #
class IO:
    @staticmethod
    def print_menu():
        print('''
        Menu of Options
        1) Load Data from File
        2) Add a new item
        3) Remove an existing item
        4) Save Data to File 
        5) Exit Program
        ''')

    @staticmethod
    def input_menu_choice():
        choice = str(input("Which option would you like to perform? [1 to 4] - ")).strip()
        print()  # Add an extra line for looks
        return choice

    @staticmethod
    def print_current_list_items(list_of_dictionary_rows):
        print("******* The Current Items Are: *******")
        for row in list_of_dictionary_rows:
            print(row["Item"] + " $" + row["Value"])
        print("*******************************************")
        print()  # Add an extra line for looks

    @staticmethod
    def input_item_and_value():
        item = str(input("What is the item? - ")).strip()
        value = str(input("What is the value? - ")).strip()
        print()  # Add an extra line for looks
        return item, value

    @staticmethod
    def input_item_to_remove():
        item = str(input("Remove which item? - ")).strip()
        print()  # Add an extra line for looks
        return item


# Main Body of the Script  -------------------------------------------------- #
while(True):
    IO.print_current_list_items(lstTable)
    IO.print_menu()   # Test menu
    strChoice = IO.input_menu_choice()    # Test user choice

    if (strChoice == "1"):  # 1) Load Data from File
        lstTable, status = Processor.read_file_to_list_of_dictionaries(strFileName, lstTable)
        if status == 'success':
            print('Done!')
    elif (strChoice == "2"):  # 2) Add a new item
        strItem, strValue = IO.input_item_and_value()
        if status == 'success':
            print('Done!')
        lstTable, status = Processor.add_data_to_list_of_dictionaries(lstTable, strItem,strValue)
    elif (strChoice == "3"):  # 3) Remove an existing item
        strItem = IO.input_item_to_remove()
        lstTable, status = Processor.remove_data_from_list_of_dictionaries(lstTable, strItem)
        if status == 'success':
            print('Done!')
    elif (strChoice == "4"):  # 4) Save Data to File And Exit Program
        lstTable, status = Processor.write_file_from_list_of_dictionaries(strFileName, lstTable)
        if status == 'success':
            print('Done!')
    elif (strChoice == "5"):
        print("Goodbye!")
        break