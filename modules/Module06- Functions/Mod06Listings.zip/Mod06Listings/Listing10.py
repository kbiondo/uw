#-------------------------------------------------#
# Title: Listing 10
# Description: Python's version of function overloading
# ChangeLog: (Who, When, What)
# RRoot, 01.01.2030, Created Script
#-------------------------------------------------#

# -- processing code -- #
def CalcValues(value1 = 0, value2 = 0, operation = '+'):
    if operation.lower() == '+': fltAnswer = value1 + value2
    elif operation.lower() == '-': fltAnswer = abs(value1 - value2)
    elif operation.lower() == '*': fltAnswer = value1 * value2
    elif operation.lower() == '/': fltAnswer = value1 / value2
    else: fltAnswer = "Error"
    return value1, operation, value2, fltAnswer

# -- presentation (I/0) code -- #
print(CalcValues())
print(CalcValues(5,10))
print(CalcValues(5,10,'*'))
