#-------------------------------------------------#
# Title: Listing 15
# Description: Global variable Shadowing
# ChangeLog: (Who, When, What)
# RRoot, 01.01.2030, Created Script
#-------------------------------------------------#

# -- data code -- #
# Note: Variables declared in the body of the script are "Global"
v1 = 10    # first argument
v2 = 5     # second argument
answer = None  # result of processing

# -- processing code -- #
def AddValues(value1, value2):
   answer = value1 + value2  # answer shadowed the global variable

# -- presentation (I/0) code -- #
AddValues(v1, v2)
print('Global = ', answer)