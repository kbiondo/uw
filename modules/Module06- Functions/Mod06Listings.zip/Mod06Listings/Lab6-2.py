#-------------------------------------------------#
# Title: Lab 6-2
# Description: Returning multiple values as a tuple
# ChangeLog: (Who, When, What)
# RRoot, 01.01.2030, Created Script
#-------------------------------------------------#

# -- data code --
fltV1 = None    # first argument
fltV2 = None    # second argument
fltSum = None   # first result of processing
fltDiff = None  # second result of processing
fltProd = None  # third result of processing
fltQuot = None  # fourth result of processing


# Define the function
def CalculateValues(value1, value2):
    sum = value1 + value2
    diff = abs(value1 - value2)
    prod = value1 * value2
    #  quot = value1 / value2
    return sum, diff, prod, (value1 / value2)  # skipping quot variable


# Call the function and capture the results
fltV1 = float(input("Enter value 1: "))
fltV2 = float(input("Enter value 2: "))
fltSum, fltDiff, fltProd, fltQuot = CalculateValues(fltV1, fltV2)
print("The Sum of %.2f and %.2f is %.2f" % (fltV1, fltV2, fltSum))
print("The Difference of %.2f and %.2f is %.2f" % (fltV1, fltV2, fltDiff))
print("The Product of %.2f and %.2f is %.2f" % (fltV1, fltV2, fltProd))
print("The Quotient of %.2f and %.2f is %.2f" % (fltV1, fltV2, fltQuot))

