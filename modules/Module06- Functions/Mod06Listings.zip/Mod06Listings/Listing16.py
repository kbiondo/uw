#-------------------------------------------------#
# Title: Listing 16
# Description: Global variable implicit reference
# ChangeLog: (Who, When, What)
# RRoot, 01.01.2030, Created Script
#-------------------------------------------------#

# -- data code -- #
# Note: Variables declared in the body of the script are "Global"
v1 = 10
v2 = 5
answer = None

# -- processing code -- #
def AddValues():
   answer = v1 + v2  # v1 and v2 refer to the "global" variables
   print(answer)  # answer is a "local" variable

# -- presentation (I/0) code -- #
AddValues()
print('Global = ', answer)
