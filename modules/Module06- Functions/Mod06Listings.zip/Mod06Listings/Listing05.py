# ------------------------------------------------- #
# Title: Listing 5
# Description: Using a function's return value
# ChangeLog: (Who, When, What)
# RRoot,1.1.2030,Created Script
# ------------------------------------------------- #

# -- processing code -- #
def AddValues(value1, value2):
    fltAnswer = value1 + value2
    return fltAnswer

# Call the function and capture the results
fltResults = AddValues(10, 5)
print("The Sum of the values is: " + str(fltResults))

# Or call the function and uses as an expression
print("The Sum of the values is: " + str(AddValues(10, 5)))

