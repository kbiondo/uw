#-------------------------------------------------#
# Title: Listing 04
# Description: Using variables as arguments
# ChangeLog: (Who, When, What)
# RRoot, 01.01.2030, Created Script
#-------------------------------------------------#

# -- data code -- #
fltV1 = None       # first argument
fltV2 = None       # second argument
fltResults = None  # result of processing

# -- processing code -- #
def AddValues(value1, value2):
    fltAnswer = value1 + value2
    print(fltAnswer)


# -- presentation (I/0) code -- #
# fltV1 = float(input("Enter value 1: "))
# fltV2 = float(input("Enter value 2: "))
# print("The Sum of %.3f and %.2f" % (fltV1, fltV2))
# print("is: ", end='')
AddValues(float(input("Enter value 1: ")), float(input("Enter value 2: ")))