#-------------------------------------------------#
# Title: Listing 14
# Description: Global variables
# ChangeLog: (Who, When, What)
# RRoot, 01.01.2030, Created Script
#-------------------------------------------------#

# -- data code -- #
# Note: Variables declared in the body of the script are "Global"
v1 = 10    # first argument
v2 = 5     # second argument
gAnswer = None  # result of processing

# --processing code-- #
def AddValues(value1, value2):
   global gAnswer  # This refers to the "global" variable
   gAnswer = value1 + value2
   answer = value1 + value2  # This is a "local" variable!
   return answer

# --presentation (I/0) code -- #
AddValues(v1, v2)
print('Global = ', gAnswer)
print('Local = ', AddValues(v1, v2))
