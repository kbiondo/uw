# ------------------------------------------------- #
# Title: Lab 6-1
# Description: Basic Arithmetic
# ChangeLog: (Who, When, What)
# RRoot,1.1.2030,Created Script
# ------------------------------------------------- #


# Define the function
def CalculateValues(value1, value2):
    fltSum = value1 + value2
    fltDiff = abs(value1 - value2)
    fltProd = value1 * value2
    fltQuot = value1 / value2
    print("The Sum of the values is: " + str(fltSum))
    print("The Difference of the values is: " + str(fltDiff))
    print("The Product of the values is: " + str(fltProd))
    print("The Quotient of the values is: " + str(fltQuot))


# Call the function
CalculateValues(10, 5)
