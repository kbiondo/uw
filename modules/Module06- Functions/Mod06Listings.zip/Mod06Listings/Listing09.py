#-------------------------------------------------#
# Title: Listing 09
# Description: Using default parameter values
# ChangeLog: (Who, When, What)
# RRoot, 01.01.2030, Created Script
#-------------------------------------------------#

# -- data code -- #
fltV1 = None  # first argument
fltV2 = None  # second argument
fltR1 = None  # first result of processing
fltR2 = None  # second result of processing
fltR3 = None  # third result of processing

# -- processing code -- #
def AddValues(value1 = 0, value2 = 0):
    fltAnswer = value1 + value2
    return value1, value2, fltAnswer

# -- presentation (I/0) code -- #
fltV1 = float(input("Enter value 1: "))
fltV2 = float(input("Enter value 2: "))
fltR1, fltR2, fltR3 = AddValues(value2 = fltV2)
print("The Sum of %.2f and %.2f is %.2f" % (fltR1, fltR2, fltR3))