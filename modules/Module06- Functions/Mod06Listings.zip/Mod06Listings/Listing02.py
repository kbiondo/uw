# ------------------------------------------------- #
# Title: Listing 2
# Description: Calling a function with parameters
# ChangeLog: (Who, When, What)
# RRoot,1.1.2030,Created Script
# ------------------------------------------------- #

# Define the function
def ProcessSomething(parmMessage):
    print("The parameter was: " + parmMessage)


# Call the function
ProcessSomething("arg ABC")
