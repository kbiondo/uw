def MyFunction():
    v1 = 15  #local
    print(v1)

MyFunction()
print(v1)  # NameError: name 'v1' is not defined


