#-------------------------------------------------#
# Title: Lab 6-3
# Description: Using Functions in a Class
# ChangeLog: (Who, When, What)
# RRoot, 01.01.2030, Created Script
#-------------------------------------------------#

# -- data code -- #
fltV1 = 0.0  # First number to for calculation
fltV2 = 0.0  # Second number to for calculation

# -- processing code -- #
class MathProcessor():
    """
    Desc - Functions for processing simple math
    """
    @staticmethod
    def AddValues(value1=0, value2=0):
        """
        Desc - This function adds two values

        :param value1: (int or float) the first number to add
        :param value2: (int or float) the second number to add
        :return: (int or float) sum of two numbers
        """
        fltAnswer = value1 + value2
        return fltAnswer

    @staticmethod
    def SubtractValues(value1=0, value2=0):
        """
        Desc - This function subtracts two values

        :param value1: (int or float) the first number to subtract
        :param value2: (int or float) the second number to subtract
        :return: (int or float) sum of two numbers
        """
        fltAnswer = value1 - value2
        return fltAnswer

    @staticmethod
    def MultiplyValues(value1=0, value2=0):
        """
        Desc - This function multiplies two values

        :param value1: (int or float) the first number to subtract
        :param value2: (int or float) the second number to subtract
        :return: (int or float) sum of two numbers
        """
        fltAnswer = value1 * value2
        return fltAnswer

    @staticmethod
    def DivideValues(value1=0, value2=0):
        """
        Desc - This function divides two values

        :param value1: (int or float) the first number to subtract
        :param value2: (int or float) the second number to subtract
        :return: (int or float) sum of two numbers
        """
        fltAnswer = value1 / value2
        return fltAnswer

# -- presentation (I/0) code -- #
fltV1 = float(input("Enter value 1: "))
fltV2 = float(input("Enter value 2: "))
print("The Sum of %.2f and %.2f is %.2f" % (fltV1, fltV2, MathProcessor.AddValues(fltV1, fltV2)))
print("The Difference of %.2f and %.2f is %.2f" % (fltV1, fltV2, MathProcessor.SubtractValues(fltV1, fltV2)))
print("The Product of %.2f and %.2f is %.2f" % (fltV1, fltV2, MathProcessor.MultiplyValues(fltV1, fltV2)))
print("The Quotient of %.2f and %.2f is %.2f" % (fltV1, fltV2, MathProcessor.DivideValues(fltV1, fltV2)))

