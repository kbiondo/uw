#-------------------------------------------------#
# Title: Listing 13
# Description: Python's version of by val and by ref
# ChangeLog: (Who, When, What)
# RRoot, 01.01.2030, Created Script
#-------------------------------------------------#

# -- data code -- #
v1 = 5
v2 = 10
lstData = [0, 0, 0, 0]
dicData = {"sum": 0, "diff": 0, "prod": 0, "quot": 0}

# -- processing code -- #
def CalcListValues(value1, value2, all_answers):
        answers[0] = value1 + value2
        answers[1] = value1 - value2
        answers[2] = value1 * value2
        answers[3] = value1 / value2

def CalcDictionaryValues(value1, value2, all_answers):
        answers["sum"] = value1 + value2
        answers["diff"] = value1 - value2
        answers["prod"] = value1 * value2
        answers["quot"] = value1 / value2

# -- presentation (I/0) code -- #
CalcListValues(value1 = v1, value2 = v2, all_answers = lstData)
print(lstData)

CalcDictionaryValues(value1 = v1, value2 = v2, all_answers = dicData)
print(dicData)
