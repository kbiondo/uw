#-------------------------------------------------#
# Title: Listing 12
# Description: Python's version of by val and by ref
# ChangeLog: (Who, When, What)
# RRoot, 01.01.2030, Created Script
#-------------------------------------------------#

# Simple data
x = 1
y = x
x = 3
print(y) # Print 1, as if only the value was passed!

# Complex data
x = [1, 2] # This is a Python List
y = x
x[0] = 3
print(y) # Prints [3,2], as expected of a reference!

# Simple data
x = "Bob"
y = x
x = "Robert"
print(y) # Print "Bob", as if only the value was passed!

# Complex data
x =("Bob", "Sue")
y = x
x = ("Robert")
print(y) # Prints ['Robert', Sue], as expected of a reference!

