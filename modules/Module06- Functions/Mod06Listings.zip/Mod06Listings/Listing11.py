#-------------------------------------------------#
# Title: Listing 11
# Description: Python's version of function overloading
# ChangeLog: (Who, When, What)
# RRoot, 01.01.2030, Created Script
#-------------------------------------------------#

# -- processing code -- #
def CalcValues(value1 = None, value2 = None, operation = None):
    if value1 is None or value2 is None or operation is None:
        fltAnswer = "Error: Missing Arguments"
    elif operation.lower() == '+': fltAnswer = value1 + value2
    elif operation.lower() == '-': fltAnswer = abs(value1 - value2)
    elif operation.lower() == '*': fltAnswer = value1 * value2
    elif operation.lower() == '/': fltAnswer = value1 / value2
    else: fltAnswer = "Error"
    return value1, operation, value2, fltAnswer

# -- presentation (I/0) code -- #
print(CalcValues())
print(CalcValues(5, 10))
print(CalcValues(5, 10, '*'))

