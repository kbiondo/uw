# ------------------------------------------------- #
# Title: Listing 1
# Description: Calling a function
# ChangeLog: (Who, When, What)
# RRoot,1.1.2030,Created Script
# ------------------------------------------------- #

# Define the function
def ProcessSomething():
    print("I'm")  # first statement
    print("processing data")  # second statement

# Call the function
ProcessSomething()
