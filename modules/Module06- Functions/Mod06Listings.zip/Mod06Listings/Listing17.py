# -------------------------------------------------#
# Title: Listing 17
# Description: Using classes
# ChangeLog: (Who, When, What)
# RRoot, 01.01.2030, Created Script
# -------------------------------------------------#

# -- processing code -- #
class MathProcessor():
    """ functions for processing simple math """
    @staticmethod
    def AddValues(value1=0.0, value2=0.0):
        """ This function adds two values

        :param value1: (float) the first number to add
        :param value2: (float) the second number to add
        :return: (float) sum of two numbers
        """
        return float(value1 + value2)

    @staticmethod
    def SubtractValues(value1=0.0, value2=0.0):
        """
        This function subtracts two values

        :param value1: (float) the first number to subtract
        :param value2: (float) the second number to subtract
        :return: (float) sum of two numbers
        """
        return float(value1 - value2)


# -- presentation (I/0) code -- #
print(MathProcessor.AddValues(5,10))
print(MathProcessor.SubtractValues(5,10))
