def OutputMenuItems():
    """  Display a menu of choices to the user
    :return: nothing
    """
    print('''
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Reload Data from File
    6) Exit Program
    ''')
    print()  # Add an extra line for looks

# ---------------- Main --------------
OutputMenuItems()