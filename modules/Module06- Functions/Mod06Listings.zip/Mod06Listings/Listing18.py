# -------------------------------------------------#
# Title: Listing 17
# Description: Using classes
# ChangeLog: (Who, When, What)
# RRoot, 01.01.2030, Created Script
# -------------------------------------------------#

# -- processing code -- #
class MathProcessor():
    """
    Desc - functions for processing simple math
    """
    @staticmethod
    def AddValues(value1=0, value2=0):
        """
        Desc - This function adds two values

        :param value1: (int or float) the first number to add
        :param value2: (int or float) the second number to add
        :return: (int or float) sum of two numbers
        """
        fltAnswer = value1 + value2
        return fltAnswer

    @staticmethod
    def SubtractValues(value1=0, value2=0):
        """
        Desc - This function subtracts two values

        :param value1: (int or float) the first number to subtract
        :param value2: (int or float) the second number to subtract
        :return: (int or float) sum of two numbers
        """
        fltAnswer = value1 - value2
        return fltAnswer


# -- presentation (I/0) code -- #
print(MathProcessor.AddValues(5,10))
print(MathProcessor.SubtractValues(5,10))
