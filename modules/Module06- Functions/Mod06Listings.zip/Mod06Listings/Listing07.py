#-------------------------------------------------#
# Title: Listing 07
# Description: Returning multiple values as a list
# ChangeLog: (Who, When, What)
# RRoot, 01.01.2030, Created Script
#-------------------------------------------------#

# -- data code -- #
fltV1 = None  # first argument
fltV2 = None  # second argument
lstResults = None  # list of results for processing

# -- processing code -- #
def AddValues(value1, value2):
    fltAnswer = value1 + value2
    return [value1, value2, fltAnswer]  # create list

# -- presentation (I/0) code -- #
fltV1 = float(input("Enter value 1: "))
fltV2 = float(input("Enter value 2: "))
lstResults = AddValues(fltV1, fltV2)  # capture list
print("The Sum of %.2f and %.2f is %.2f" %
       (lstResults[0], lstResults[1], lstResults[2]))
