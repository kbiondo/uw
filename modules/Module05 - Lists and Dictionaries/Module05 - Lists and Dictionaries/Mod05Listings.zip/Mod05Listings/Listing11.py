# -------------------------------------------------- #
# Title: Listing 11
# Description: A three section example
# ChangeLog (Who,When,What):
# RRoot,1.1.2030,Created started script
# <Your Name Here>,<Date>,Changed rows from lists to dictionaries
# -------------------------------------------------- #

# -- Data -- #
fltN1 = 0.0  # 1
fltN2 = 0.0  # 2

# -- Presentation (Input/Output) -- #
fltN1 = float(input("Enter the first number: "))  # 3
fltN2 = float(input("Enter the second number: ")) # 4

# -- Processing -- #
fltQuot = (fltN1 / fltN2)  # 5
print(fltQuot)  # 6, presentation code, but still needed here!
