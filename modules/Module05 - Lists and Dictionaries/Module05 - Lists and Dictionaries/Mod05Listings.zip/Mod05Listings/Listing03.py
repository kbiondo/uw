# -------------------------------------------------- #
# Title: Listing 3
# Description: Reading Data from a file to a list
# ChangeLog (Who,When,What):
# RRoot,1.1.2030,Created script
# -------------------------------------------------- #

# Declare my variables
lstRow = []
strFile = 'MyData.txt'
objFile = None

# Process the data
objFile = open(strFile, "r")
for row in objFile:
    lstRow = row.split(",")
    print(lstRow)
    print(lstRow[0] + '|' + lstRow[1] + '|' + lstRow[2].strip())
objFile.close()
