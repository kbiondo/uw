# -------------------------------------------------- #
# Title: Listing 5
# Description: Reading and Writing to a dictionary
# ChangeLog (Who,When,What):
# RRoot,1.1.2030,Created script
# -------------------------------------------------- #

# Declare my variables
dicRow = {}

# Process the data
dicRow = {"ID": "1", "Name": "Bob Smith", "Email": "BSmith@Hotmail.com\n"}
print(dicRow)
print(dicRow["ID"] + ',' + dicRow["Name"] + ',' + dicRow["Email"])
print('Note the invisible newline!')
