# -------------------------------------------------- #
# Title: Listing 6
# Description: Working with a list of dictionary objects
# ChangeLog (Who,When,What):
# RRoot,1.1.2030,Created script
# -------------------------------------------------- #

# Create data structure
dicRow1 = {"ID":1,"Name":"Bob Smith", "Email":"BSmith@Hotmail.com"}
dicRow2 = {"ID":"2","Name":"Sue Jones", "Email":"SueJ@Yahoo.com"}
lstTable = [dicRow1, dicRow2]

# Process the data
print("\n--- items in the list 'Table'")
print(lstTable)
for objRow in lstTable:
    print(objRow)

print("\n--- Unpacking the elements with the items() function")
for myKey, myValue in dicRow1.items():
    print(myKey, " = ", myValue )

print("\n--- Displaying only the values()")
print(dicRow1.values())

print("\n--- Displaying only the keys()")
print(dicRow1.keys())
