# -------------------------------------------------- #
# Title: Listing 7
# Description: Adding user data to the "table"
# ChangeLog (Who,When,What):
# RRoot,1.1.2030,Created script
# -------------------------------------------------- #

# Data
strFile = 'MyData.txt'
objFile = None
dicRow1 = {}
lstTable = []

# Create the table
dicRow1 = {"id":"1","name":"Bob Smith", "email":"BSmith@Hotmail.com"}
lstTable.append(dicRow1)

# Process the data
for objRow in lstTable:
    print(objRow)

# Get User Input
strID = input("Enter an ID: ")
strName = input("Enter an Name: ")
strEmail = input("Enter an Email: ")
dicRow2 = {"id": strID,"name": strName, "email": strEmail}
lstTable.append(dicRow2)
print(lstTable)
for objRow in lstTable:
    print(objRow)
