# -------------------------------------------------- #
# Title: Listing 1
# Description: Reading and Writing to a list
# ChangeLog (Who,When,What):
# RRoot,1.1.2030,Created script
# -------------------------------------------------- #

# Declare my variables
lstRow = []

# Process the data
lstRow = ["1", "Bob Smith", "BSmith@Hotmail.com\n"]
print(lstRow)
print(lstRow[0] + ',' + lstRow[1] + ',' + lstRow[2])
print('Note the invisible newline!')
