# -------------------------------------------------- #
# Title: Listing 2
# Description: Writing Data from a list to a file
# ChangeLog (Who,When,What):
# RRoot,1.1.2030,Created script
# -------------------------------------------------- #

# Declare my variables
lstRow = []
strFile = 'MyData.txt'
objFile = None

# Process the data
objFile = open(strFile, "w")
lstRow = ["1", "Bob Smith", "BSmith@Hotmail.com"]
objFile.write(lstRow[0] + ',' + lstRow[1] + ',' + lstRow[2] + '\n')
objFile.close()
