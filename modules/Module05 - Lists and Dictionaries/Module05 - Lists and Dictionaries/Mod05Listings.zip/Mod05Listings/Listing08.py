# -------------------------------------------------- #
# Title: Listing 8
# Description: Adding file data to the "table"
# ChangeLog (Who,When,What):
# RRoot,1.1.2030,Created script
# -------------------------------------------------- #

# Data
strFile = 'MyData.txt'
objFile = None
dicRow = {}
lstTable = []

# Process the data
objFile = open(strFile, "r")
for row in objFile:
    lstRow = row.split(",")
    dicRow = {"id": lstRow[0],"name": lstRow[1],"email": lstRow[2].strip()}
    lstTable.append(dicRow)
objFile.close()

print(lstTable)
