# -- Data -- #
fltN1 = 0.0
fltN2 = 0.0


# -- Processing -- #
def divide_values():  # 4
    return (fltN1 / fltN2)  # 5


# -- Presentation (Input/Output) -- #
fltN1 = float(input("Enter the first number: "))  # 1
fltN2 = float(input("Enter the second number: "))  # 2
print(divide_values())  # 3
print("Done")  # 6
