#-------------------------------------------------#
# Title: Listing 12
# Description: A three section example using a function
# ChangeLog: (Who, When, What)
# <Example Dev, 01/01/2030, Created Script>
#-------------------------------------------------#

# -- Data -- #
fltN1 = 0.0  # 1
fltN2 = 0.0  # 2

# -- Processing -- #
def DivideValues():  # 6 , this code loads but does not run yet!
    return (fltN1 / fltN2)  # 7

# -- Presentation (I/O) -- #
fltN1 = float(input("Enter the first number: "))  # 3
fltN2 = float(input("Enter the second number: "))  # 4
print(DivideValues())  # 5
print("Done")  # 8

